function [out] = makeGroundTruth(PathName)
%==========================================================================
%
% function [out] = makeGroundTruth(PathName)
%
% This function creates a graphical user interface where the user is able
% to choose a ground truth.  The function will run so as long as the image
% window stays open.  Once closed, the function will terminate and send
% back the data structure seen in the output.
% 
% Once running, there are 3 options
% 1) Close: This will close the window (even though just closing the window
%           will acomplish the same task)
% 2) Mark Target: This button promps the user to choose the center of the
% target.  In the event no bounding box size is specified, the program will
% declare a predesignated box size (this can be modified in the code)
% 
% 3) Bounding Box: This will allow the user to pick 2 corners to form a
% rectangle. If no center point is previously selected, the program will
% choose the center point to be in the middle of the selected area.
% 
% Input:
%   -PathName: (Optional) provide path name for files to be extraceted.  kf
%   the path name is not speified, one will be chosen after running.
%
% Output:
%   -out: data structure with the following parameters
%     out.x = x coordinates of the ground truth
%     out.y = coordinates of the ground truth
%     out.GT = ground_truth image set
%     out.im = origional images chosen
%     out.seq = grayscale sequence
%     out.box = boundingBox coordinates 
% 
% Author: N.Ferrante (San Diego State University)
% Email:  nferrante@sdsu.edu
% Date: 08/14/2018
% Version: 1.0
%==========================================================================
     if ~isempty(findobj('type','figure','name','Ground Truth Editor'))
        close 'Ground Truth Editor'
     end
    %% Load Images
    if nargin < 1
        [FileNames,PathName] = uigetfile('*.png', 'Chose files to load:','MultiSelect','on');
    else
        thisDir = dir([PathName, '*.png']);
        FileNames = cell(length(thisDir), 1);
        for kk = 1:length(thisDir)
            FileNames{kk} = thisDir(kk).name;
        end
    end
    %% Get image infromation
    % Make global data to be passed around the app
    global im_structure
    global frame
    global nfiles
    global close_flag
    global used_points
    global point
    global pbox
    global carDims
    global boundingBox
    global default_box_size
    
    % Fill initial values for the global data
    close_flag = 0;
    nfiles = length(FileNames); 
    frame = 1;
    im_structure = {nfiles};
    used_points = zeros(nfiles, 1);
    carDims     = zeros(nfiles, 2);
    boundingBox = zeros(nfiles, 4);
    default_box_size = 80;
    
    % Load image structure
    for i = 1:nfiles
      image = imread([PathName, FileNames{i}]);
      im_structure{i} = image;
    end
    % The first image is selected to be displayed
    I_tmp = im_structure{1};
    [row, col, ~] = size(I_tmp);
    ground_truth = zeros(row, col, nfiles);
    seq = zeros(row, col, nfiles);
    x = zeros(nfiles, 1);
    y = zeros(nfiles, 1);
    % This pad is for the button location and the figure size around the
    % image
    pad = 50;
    
    % Right: [right, up] is the pixel location to plot the bottom left
    % corner of the gui from the [0, 0] locaiton on the physical screen
    right = 225;
    up = 100;
    % Fill image to display
    handles.Image = im_structure{1};
    % Set figure
    handles.fig = figure('Name','Ground Truth Editor', 'Resize', 'on', 'NumberTitle','off', 'units','normalized','outerposition',[0 0 1 1]);
    % Update to use pixel units
    handles.axes1 = axes('Units','normalized');
    % Make slider
    handles.slider = uicontrol('Style','slider', 'Units','normalized','Position', [-10 -10 .1 .1],'Min',1,'Max',nfiles,'Value',1, 'SliderStep', [1/nfiles, 1/nfiles]);
    % Use slider to update figure
    handles.Listener = addlistener(handles.slider,'Value','PostSet',@(s,e) change_image);
    imshow(handles.Image,'Parent',handles.axes1);
    hold on
    guidata(handles.fig);
    % Create Point Marker button
    button_width = row/4;
    handles.mp = uicontrol('Style', 'pushbutton', 'String', 'Mark Point',...
        'Position', [(col+2*pad)/2 - button_width/2, (pad/2) + pad, button_width, 20],...
        'Callback', @(s, e) findPoint);
    % Create Close button
    handles.close = uicontrol('Style', 'pushbutton', 'String', 'close',...
        'Position', [(col+2*pad)/2 - 2*button_width  , (pad/2) + pad, button_width, 20],...
        'Callback', @(s, e) close_fig);
    % Create Bounding Box button
    handles.updateBox = uicontrol('Style', 'pushbutton', 'String', 'Bounding Box',...
        'Position', [(col+2*pad)/2 + button_width, (pad/2) + pad, button_width, 20],...
        'Callback', @(s, e) updateBox);

    %% Image Updator
    function change_image
        % Fill the slider value (note that it must be an integer)
        slider_value = round(get(handles.slider,'Value'));
        % Update image from slider
        frame = round(slider_value);
        
        % Update the image
        handles.Image=im_structure{frame};
        axes(handles.axes1);
        % Show the image
        imshow(handles.Image)
        hold on
        % If there is a known value for the an object, it is plotted
        if x(frame) ~= 0 && y(frame) ~= 0
            point = plot(x(frame), y(frame), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
            plot_box();
        end
    end
    %% Point Finder
    function findPoint
        
        % User inputs the location of the object
        [x_tmp, y_tmp] = ginput(1);
        % Object location is updated
        x(frame) = round(x_tmp);
        y(frame) = round(y_tmp);
        
        % Old point are deleted and new point is plotted
        delete(point)
        point = plot(x(frame), y(frame), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
        if used_points(frame) == 0
           used_points(frame) = 1;
        end
        % Point value is storred and the bounding box is created
        updatePoints();
        plot_box();
    end
    
    %% Update known points
    function [] = updatePoints()
        if used_points(frame) ~= 0
            tmp = find(used_points);
            % Check to see if there is now previously known point
            if length(tmp) == 1
                ind = frame;
            else
                % Given there is a known previous point for the object, that
                % point is then chosen to interpolate from
                this_ind = find(tmp == frame);
                ind = tmp(this_ind-1);
            end
            check = find(used_points);
            if frame == check(end)
                % Interpolation is made between left neighbor and and new point.
                x(ind:frame) = round(linspace(x(ind), x(frame), frame-ind + 1))';
                y(ind:frame) = round(linspace(y(ind), y(frame), frame-ind + 1))';
                    % Bounding box is created around the known point
                if carDims(frame, 1) == 0 && carDims(frame, 2) == 0
                    % Case if no size has been stated
                    boundingBox(ind:frame, 1) = x(ind:frame) - round(default_box_size/2);
                    boundingBox(ind:frame, 2) = x(ind:frame) + round(default_box_size/2);
                    boundingBox(ind:frame, 3) = y(ind:frame) - round(default_box_size/2);
                    boundingBox(ind:frame, 4) = y(ind:frame) + round(default_box_size/2);
                else
                    % Case if a size has been made
                    boundingBox(ind:frame, 1) = x(ind:frame) - round(carDims(ind:frame, 1)/2);
                    boundingBox(ind:frame, 2) = x(ind:frame) + round(carDims(ind:frame, 1)/2);
                    boundingBox(ind:frame, 3) = y(ind:frame) - round(carDims(ind:frame, 2)/2);
                    boundingBox(ind:frame, 4) = y(ind:frame) + round(carDims(ind:frame, 2)/2);
                end
            else
                % Interpolation is made between left and right neighbor and new point.
                ind2 = tmp(this_ind+1);
                x(ind:frame) = round(linspace(x(ind), x(frame), frame-ind + 1))';
                y(ind:frame) = round(linspace(y(ind), y(frame), frame-ind + 1))';
                x(frame:ind2) = round(linspace(x(frame), x(ind2), ind2-frame + 1))';
                y(frame:ind2) = round(linspace(y(frame), y(ind2), ind2-frame + 1))';
                
                if carDims(frame, 1) == 0 && carDims(frame, 2) == 0
                    % Bounding box is created around the known point
                    % Case if no size has been stated
                    boundingBox(ind:frame, 1) = x(ind:frame) - round(default_box_size/2);
                    boundingBox(ind:frame, 2) = x(ind:frame) + round(default_box_size/2);
                    boundingBox(ind:frame, 3) = y(ind:frame) - round(default_box_size/2);
                    boundingBox(ind:frame, 4) = y(ind:frame) + round(default_box_size/2);
                    
                    boundingBox(frame:ind2, 1) = x(frame:ind2) - round(default_box_size/2);
                    boundingBox(frame:ind2, 2) = x(frame:ind2) + round(default_box_size/2);
                    boundingBox(frame:ind2, 3) = y(frame:ind2) - round(default_box_size/2);
                    boundingBox(frame:ind2, 4) = y(frame:ind2) + round(default_box_size/2);
                else
                    % Case if a size has been made
                    boundingBox(ind:frame, 1) = x(ind:frame) - round(carDims(ind:frame, 1)/2);
                    boundingBox(ind:frame, 2) = x(ind:frame) + round(carDims(ind:frame, 1)/2);
                    boundingBox(ind:frame, 3) = y(ind:frame) - round(carDims(ind:frame, 2)/2);
                    boundingBox(ind:frame, 4) = y(ind:frame) + round(carDims(ind:frame, 2)/2);
                    
                    
                    boundingBox(frame:ind2, 1) = x(frame:ind2) - round(carDims(frame:ind2, 1)/2);
                    boundingBox(frame:ind2, 2) = x(frame:ind2) + round(carDims(frame:ind2, 1)/2);
                    boundingBox(frame:ind2, 3) = y(frame:ind2) - round(carDims(frame:ind2, 2)/2);
                    boundingBox(frame:ind2, 4) = y(frame:ind2) + round(carDims(frame:ind2, 2)/2);
                end
            end
            
        end
    end
    %% Close figure
    function [] = close_fig()
        close 'Ground Truth Editor'
        close_flag = 1;
    end

    %% Update box size
    function [] = updateBox()
        xpt = zeros(2, 1); ypt = zeros(2, 1);
        % User selects one corner of the object and it is plotted in red
        [xpt(2), ypt(2)] = ginput(1);
        tmp_plot = plot(round(xpt(2)), round(ypt(2)), 'ro', 'MarkerSize', 2, 'MarkerFaceColor', 'r');
        % User selects opposite corner of the object
        [xpt(1), ypt(1)] = ginput(1);
        % Origional dot is removed
        delete(tmp_plot)
        % Dimensions from this frame forward will reflect this size
        carDims(frame:end, 1) = round(abs(xpt(2) - xpt(1)));
        carDims(frame:end, 2) = round(abs(ypt(2) - ypt(1)));
        % If a point of the object is known, points are updated and plotted
        if used_points(frame) == 1
            updatePoints();
            plot_box();
        else
            x(frame) = round((xpt(2) + xpt(1))/2);
            y(frame) = round((ypt(2) + ypt(1))/2);
            used_points(frame) = 1;
            point = plot(x(frame), y(frame), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
            updatePoints();
            plot_box();
        end
        
    end
    
    %% Plot the box
    function [] = plot_box()
        % Here the box is plotted around the point.
        xPlot = [boundingBox(frame, 1), boundingBox(frame, 2)];
        yPlot = [boundingBox(frame, 3), boundingBox(frame, 4)];
        
        % Old point box is removed
        delete(pbox);
        % New point box is created by plotting points clockwise around the
        % center selected point locaiton
        pbox  = plot([xPlot(1), xPlot(2), xPlot(2), xPlot(1), xPlot(1)], [yPlot(1), yPlot(1), yPlot(2), yPlot(2), yPlot(1)], 'r-', 'LineWidth', 2);
    end

    %% Loop to update data by way of the gui
    % In order to keep the gui open and updating the data it returns, this
    % loop is made to be running so as long as the gui widow is open.  When
    % the window is either closed, or the 'close' button is pressed, the
    % flag is lifted and the while loop terminates
    while close_flag == 0
        pause(0.001)
        if isempty(findobj('type','figure','name','Ground Truth Editor'))
            close_flag = 1;
        end
    end
    
    
    %% Update data to be sent back
    % Here data is updated and collected to be sent back to the user in a
    % structure.
    
    for kk = 1:find(used_points, 1, 'last')
        seq(:, :, kk) = rgb2gray(im_structure{kk});
        ground_truth(boundingBox(kk, 3):boundingBox(kk, 4), boundingBox(kk, 1):boundingBox(kk, 2), kk) = 1;
    end
    
    out.x = x;
    out.y = y;
    out.GT = ground_truth;
    out.im = im_structure;
    out.seq = seq;
    out.box = boundingBox;
end
 