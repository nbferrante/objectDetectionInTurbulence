frame = size(J, 3) - 1;

name = 'seq_11_turb_decomposition';
v = VideoWriter(name);
open(v);
set(gca,'nextplot'); 
figure(1);
for kk = 1:frame
    subplot(2, 3, 1)
    imshow(J(:, :, kk), [])
    title(['Frame (', num2str(kk),')'])

    subplot(2, 3, 2)
    imshow(C_Corrected_flow_u(:, :, :, kk), [])
    title('Cartoon')

    subplot(2, 3, 3)
    imshow(C_Corrected_flow_T(:, :, :, kk), [])
    title('Translation')

    subplot(2, 3, 4)
    imshow(C_flow(:, :, :, kk), [])
    title('HS Flow')

    subplot(2, 3, 5)
    imshow(C_Corrected_flow_v(:, :, :, kk), [])
    title('Texture')

    subplot(2, 3, 6)
    imshow(C_Corrected_flow_R(:, :, :, kk), [])
    title('Rotation')
    
    
    frame = getframe(gcf);
    writeVideo(v,frame);
end
close(1);
close(v);
