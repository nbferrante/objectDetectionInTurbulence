
Video = VideoReader('Warped_pedestrian.avi');
ii = 1;

while hasFrame(Video)
   img = readFrame(Video);
   filename = [sprintf('%03d',ii) '.jpg'];
   fullname = fullfile(workingDir,'warpedimages',filename);
   img=rgb2gray(img);
   imwrite(img,fullname)    % Write out to a JPEG file (img1.jpg, img2.jpg, etc.)
   ii = ii+1;
end
