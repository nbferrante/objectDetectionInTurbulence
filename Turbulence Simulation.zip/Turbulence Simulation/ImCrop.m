function f=ImCrop(im,b)

f=zeros(size(im,1)-2*b,size(im,2)-2*b);
f=im(b+1:b+size(f,1),b+1:b+size(f,2));
