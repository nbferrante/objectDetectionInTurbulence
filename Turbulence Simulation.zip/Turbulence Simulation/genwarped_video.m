%DEMO script to generate a video sequence from temporally shifted grid points

clear all
close all

M=201;        %grid points in the y-direction
N=201;        %grid points in the x-direction
cycle=0;     %no cycling and the first frame is the original frame
Np=200;     %number of frames to generate
%Fs=25;       %Sampling rate
Fcx=5;      %Max frequency of wander in the x-dir
Fcy=5;       %Max frequency of wander in the y-dir
Ax=3;        %Max pixel wander in the x-dir
Ay=3;        %Max pixel wander in the y-dir
method='f';  %Fourier interpolation, alternative linear 'l' is painfully slow!

videoObj = VideoReader('./vid/Courtyard2.avi');
FrameRate=videoObj.FrameRate;
Fs=FrameRate;      %Sampling rate
[Mv,Is,Js,t]=genwarpedseq(videoObj,method,0,Np,Fs,Fcx,Fcy,Ax,Ay,M,N,cycle,0);
seq.Mv=Mv;
seq.Is=Is;
seq.Js=Js;
seq.t=t;
seq.Np=Np; 
seq.Fs=Fs; 
seq.Fcx=Fcx;
seq.Fcy=Fcy;
seq.Ax=Ax;
seq.Ay=Ay;
seq.M=M;
seq.N=N;
seq.cycle=cycle;
J = zeros(size(Mv(1).cdata,1), size(Mv(1).cdata,2), length(Mv));
for ii = 1:length(Mv)
J(:,:,ii) = Mv(ii).cdata;
end
J = (J-min(J(:)))/(max(J(:))-min(J(:)));
% 
% [row, col] = size(Mv(1).cdata);
% seq_out = zeros(row, col, Np);
% for kk = 1:Np
%     tmp_im = zeros(row, col, 3);
%     tmp_cdata = Mv(kk).cdata;
%     tmp_colormap = Mv(kk).colormap;
%     for ii = 1:row
%         for jj = 1:col
%             tmp_im(ii, jj, :) = tmp_colormap(tmp_cdata(ii, jj) + 1, :);
%         end
%     end
%     seq_out(:, :, kk) = rgb2gray(tmp_im);
% end
% 
% implay(seq_out);

% save Warped_test_seq_11 seq    %Save as mat file containing all data in structure form, including the raw random walk
% moviesave(seq.Mv,'test_seq_11.avi',FrameRate) %Save as a playable AVI video at 25fps.
% figure
% 
% movie(Mv,1)