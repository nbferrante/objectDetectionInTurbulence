function [Mv,Is,Js,t,AVR,flow]=genwarpedseq(Im,method,extension,Np,Fs,Fcx,Fcy,Ax,Ay,M,N,cycle,silent,noise)
%genwarpedseq, Copyright Murat Tahtali (2005,2015) UNSW Canberra
%               m.tahtali@adfa.edu.au
% Preferred Citation:
% Tahtali, M.; Fraser, D.; Lambert, A.J., "Restoration of Non-Uniformly Warped Images Using a Typical Frame as Prototype," TENCON 2005 2005 IEEE Region 10 , vol., no., pp.1,6, 21-24 Nov. 2005
% doi: 10.1109/TENCON.2005.301213
%           
%INPUTS:
%   Im:         Input image or video object.
%   method:     'f' for Fourier interpolation, 'l' for linear interpolation
%               'packed' for all inputs packed in Im as a structure:
% 					Im.Im
% 					Im.Np
% 					Im.Fs
% 					Im.Fcx
% 					Im.Fcy
% 					Im.Ax
% 					Im.Ay
% 					Im.M
% 					Im.N
% 					Im.cycle
% 					Im.silent
%               If the following are present in the structure, all other
%               parameters pertaining to their calculation are ignored but
%               passed back in the output structure. 
%                   Im.Is           
%                   Im.Js

%   Np:         Number of frames if cycle=0, the signal is T=Np/Fs seconds long
%               Total number of frames will be Npp=2*(Np-cycle) if cycle>0 (see below).               
%   Fs:         Sampling frequency, the signal is T=Np/Fs seconds long
%   Fcx,Fcy:    Cut-off frequency in x,y direction; maximum frequency of wander
%               present in the control points
%   Ax,Ay:      Wonder amplitude in x,y directions
%   M,N:        Control grid size MxN
%   cycle:      cycles back to frame number "cycle"
%               if cycle=0 then no cycling
%               if cycle=1 then the movie will be double the length
%                   and the original frame will be in the cycle
%               if cycle>1 then the frames until 'cycle' will be lost
%               Total number of frames will be Npp=2*(Np-cycle) if cycle>0
%   silent:     Silent if silent==1

%OUTPUTS:
%   Mv:         Movie containing the warped frames
%                   If the function is called with only 1 argument
%                   Mv is a structure in the form:
%                         Mv.Mv=Mv;
%                         Mv.Is=Is;
%                         Mv.Js=Js;
%                         Mv.t=t;
%                         Mv.Np=Np; 
%                         Mv.Fs=Fs; 
%                         Mv.Fcx=Fcx;
%                         Mv.Fcy=Fcy;
%                         Mv.Ax=Ax;
%                         Mv.Ay=Ay;
%                         Mv.M=M;
%                         Mv.N=N;
%                         Mv.cycle=cycle;
%                         Mv.AVR
%
%   Is,Js:      Warping grid control points, 
%   t:          time in seconds.
%   AVR:        Averaged frame
if isvobj(Im),
    input_is_video=true;
    vobj=Im;
    m=vobj.Height;
    n=vobj.Width;
    Nframes=vobj.FrameRate*vobj.Duration;
else
    input_is_video=false;
    [m,n]=size(Im);
end
    
    




skipgen=false;
shifts=[];
scl0=1;
Xnowarp=false;
Ynowarp=false;

if method=='packed',
    Ims=Im;     %change input variable to keep using the same variables
    Im=Ims.Im;
    if isfield(Ims,'method')
        method=Ims.method;
    end
    if isfield(Ims,'Np')
        Np=Ims.Np;
    end
    if isfield(Ims,'Fs')
        Fs=Ims.Fs;
    end
    if isfield(Ims,'Fcx')
        Fcx=Ims.Fcx;
    end
    if isfield(Ims,'Fcy')
        Fcy=Ims.Fcy;
    end
    if isfield(Ims,'Ax')
        Ax=Ims.Ax;
    end
    if isfield(Ims,'Ay')
        Ay=Ims.Ay;
    end
    if isfield(Ims,'M')
        M=Ims.M;
    end
    if isfield(Ims,'N')
        N=Ims.N;
    end
    if isfield(Ims,'cycle')
        cycle=Ims.cycle;
    end
    if isfield(Ims,'silent')
        silent=Ims.silent;
    end
    if isfield(Ims,'Is')
        Is=Ims.Is;
        skipgen=true;
    end
    if isfield(Ims,'Js')
        Js=Ims.Js;
        skipgen=true;
    end
    if isfield(Ims,'t')
        t=Ims.t;
    end
    
    if isfield(Ims,'Xnowarp')
        Xnowarp=Ims.Xnowarp;
    end

    if isfield(Ims,'Ynowarp')
        Ynowarp=Ims.Ynowarp;
    end
    

    if isfield(Ims,'noise')
        addnoise=true;
        if isfield(Ims.noise,'MEAN'),
            noise.MEAN=Ims.noise.MEAN;
        else
            noise.MEAN=0;
        end
        if isfield(Ims.noise,'SNR'),
            noise.SNR=Ims.noise.SNR;
        else
            noise.SNR=30;
        end
    else
        addnoise=false;
    end
    
else
    
    skipgen=false;
    if exist('method','var')~=1
        method='f';
    end
    
    if exist('Np','var')~=1
        Np=100;
    end
    if exist('Fs','var')~=1
        Fs=25;
    end
    
    if exist('Fcx','var')~=1
        Fcx=5;
    end
    if exist('Fcy','var')~=1
        Fcy=5;
    end
    
    if exist('Ax','var')~=1
        Ax=5;
    end
    if exist('Ay','var')~=1
        Ay=5;
    end
    
    if exist('M','var')~=1
        Fcx=13;
    end
    if exist('N','var')~=1
        Fcy=13;
    end
    
    if exist('cycle','var')~=1
        cycle=0;
    end
    if exist('silent','var')~=1
        silent=0;
    end
    if exist('noise','var')~=1
        addnoise=false;
    end
    
end


if method=='f',
    disp('Using Fourier interpolation')
elseif method=='l',
    disp('Using Linear interpolation')
end






if skipgen==false,
    [Is,Js,t]=grid_meshtemp(m,n,M,N,Ax,Ay,Np,Fs,Fcx,Fcy);
end

if cycle>0
    Npp=2*(Np-cycle);
    
    Id=Is(:,:,cycle:Np);
    Jd=Js(:,:,cycle:Np);
    Id(M,N,Npp)=0;
    Jd(M,N,Npp)=0;
    Id(:,:,Np-cycle+2:Npp)=Is(:,:,Np-1:-1:cycle+1);
    Jd(:,:,Np-cycle+2:Npp)=Js(:,:,Np-1:-1:cycle+1);
else
    Id=Is;
    Jd=Js;
    Npp=Np;
end

if input_is_video,
   Npp=min(Nframes,Npp);
end


for i=1:Npp,
    if input_is_video,
        Im=read(vobj,i); 
    end
    if method=='f',
        [OUT,Xs,Ys]=fourierWarp_mesh(Im,Is(:,:,1),Js(:,:,1),Id(:,:,i),Jd(:,:,i),1,scl0,false,Xnowarp,Ynowarp);
    elseif method=='l',
        [OUT,TMP]=warp_meshlin(Im,Is(:,:,1),Js(:,:,1),Id(:,:,i),Jd(:,:,i),1);
    end
    
    %ADD NOISE IF REQUESTED
    if addnoise
       OUT = addnoiseofsnr(OUT,noise.SNR,noise.MEAN); 
    end
    
    if silent~=1
        i   
        %[OUT2]=plot_mesh(Id(:,:,i),Jd(:,:,i),m,n,1,'l');
        if method=='f',
            disp('Using Fourier interpolation')
        elseif method=='l',
            disp('Using Linear interpolation')
        end
        figure(2)
        subplot(2,2,1)
        imshow(Im,[]);
        subplot(2,2,2)
        imshow(uint8(OUT));
        if method=='f'
            subplot(2,2,3)
            imshow(Xs);
            subplot(2,2,4)
            imshow(Ys);
        end

        drawnow
    end
    % max(max(Im))
    % min(min(Im))
    %[frm,map]=gray2ind(OUT,256);
    Mv(i)=im2frame(uint8(ImCrop(OUT,extension)),gray(256));
    
    if method=='f'
        flow(i).m5=Xs;
        flow(i).m6=Ys;
    else
        flow(i).m5=[];
        flow(i).m6=[];
    end
end




if nargout==1,
    
    outseq.Mv=Mv;
    outseq.Is=Is;
    outseq.Js=Js;
    outseq.t=t;
    outseq.Np=Np; 
    outseq.Fs=Fs; 
    outseq.Fcx=Fcx;
    outseq.Fcy=Fcy;
    outseq.Ax=Ax;
    outseq.Ay=Ay;
    outseq.M=M;
    outseq.N=N;
    outseq.cycle=cycle;
    outseq.AVR=avrmovie(Mv);
    outseq.shifts=shifts;
    outseq.method=method;
    outseq.silent=silent;
    outseq.Im=Im;
    outseq.flow=flow;
    Mv=outseq;
    
else
    AVR=avrmovie(Mv);
    
end



function [out]=prepadgrid(in)
[M,N]=size(in);
out=zeros(M+1,N+1);
out(2:M+1,2:N+1)=in;



function [xs,ys,Xs,Ys]=warpmesh2shifts(Is0,Js0,Is1,Js1,M,N,interp)
%WARPMESH2SHIFTS generates shift maps via grid mesh using Fourier
%interpolation


[m,n]=size(Is0);
ys=Is0-Is1; 
xs=Js1-Js0; 
% for i=1:M,
%     for j=1:N,
%         xs(Is0(i,j),Js0(i,j))=dJs(i,j);
%         ys(Is0(i,j),Js0(i,j))=-dIs(i,j);
%     end
% end


if nargin<7,
    interp=0;
end

if interp==1,
        Xs=FourierInterpolate(xs,N/n,M/m);
        Ys=FourierInterpolate(ys,N/n,M/m);    
        Xs=-real(Xs);
        Ys=real(Ys);
    else
        Xs=[];
        Ys=[];
end
    

function [out] = FourierInterpolate(in,interpolateX,interpolateY)

% function to perform the Fourier interpolation of an image
% written by Andrew Lambert Dec 98
%               a.lambert@adfa.edu.au

% LIMITED TO EXPAND OR REDUCE IN X ONLY - IF X AND Y ARE OPPOSITRE THEN ERROR

[n,m]=size(in);

if (nargin < 3)
   interpolateY = interpolateX;
end;
  
newsizeX = floor(m*interpolateX);
newsizeY = floor(n*interpolateY);

if ((m == newsizeX) && (n == newsizeY))
   out = in;
elseif (interpolateX>1)
    % we are expanding in X
    out=zeros(newsizeY,newsizeX)+j*zeros(newsizeY, newsizeX); % transposed deliberately
	
	F = fft2(in);
	
	halfU = floor((n+1)/2) ; % transposed deliberately
	halfV = floor((m+1)/2);
	newstartU = newsizeY - halfU;
	newstartV = newsizeX - halfV;

        % Remember the shared corner
        corner = F(halfU+1,halfV+1);

	% preattenuate the shared edge
	F(halfU+1,:) = F(halfU+1,:)./2;
	F(:,halfV+1) = F(:,halfV+1)./2;
	% now shared corner would have been attenuated twice,
        % but unfortunately will have squared the corner. Need to do corner
        % seperately.

        F(halfU+1,halfV+1) = corner/4;
	
	% bulk transfer excluding the shared edge and corner duplication
	out(1:halfU,1:halfV) = F(1:halfU,1:halfV);
	out(1:halfU,(newstartV+1):newsizeX) = F(1:halfU,(halfV+1):m);
	out((newstartU+1):newsizeY,1:halfV) = F((halfU+1):n,1:halfV);
	out((newstartU+1):newsizeY,(newstartV+1):newsizeX) = F((halfU+1):n,(halfV+1):m);
	
        % duplicate the missing edges and corner
	out(halfU+1,:)=out((newstartU+1),:);
	out(:,halfV+1)=out(:,(newstartV+1));
	
 %       h=figure;
%        imauto(log(abs(out)+1));

	out = ifft2(out);
else
  % we are reducing in X
    out=zeros(newsizeY,newsizeX)+j*zeros(newsizeY, newsizeX); % transposed deliberately
	
	F = fft2(in);
	
    %these shoudl be transposed deliberately but fft2 of rectangle doesn't
    %flip dimensions!!!! It flips the contents....
	halfV = floor((newsizeX+1)/2) ; % transposed deliberately
	halfU = floor((newsizeY+1)/2);
	newstartU = n - halfU;
	newstartV = m - halfV;
		
	%how do we fudge the common edge for this case (must be real?). CHECK THIS OUT!!!!
	% fudge the shared edge and corner (must be real valued for real valued in)
	corner = (F(halfU+1,halfV+1)+F(halfU+1,newstartV+1)+F(newstartU+1,halfV+1)+F(newstartU+1,newstartV+1))/4;
	F(newstartU+1,:) = (F(halfU+1,:)+F(newstartU+1,:))./2;
	F(:,newstartV+1) = (F(:,halfV+1)+F(:,newstartV+1))./2;

	% bulk transfer including the shared edge and corner
	out(1:halfU,1:halfV) = F(1:halfU,1:halfV);
	out(1:halfU,(halfV+1):newsizeX) = F(1:halfU,(newstartV+1):m);
	out((halfU+1):newsizeY,1:halfV) = F((newstartU+1):n,1:halfV);
	out((halfU+1):newsizeY,(halfV+1):newsizeX) = F((newstartU+1):n,(newstartV+1):m);
	
	% now shared corner would have taken in all corners  -WOULDN'T IT?
	out(halfU+1,halfV+1)=corner;

%	h=figure;
%        imauto(log(abs(out)));

        out = ifft2(out);
end


function [Out,Xs,Ys,scl]=fourierWarp_mesh(Im,Is,Js,Id,Jd,silent,scl0,nowarp,Xnowarp,Ynowarp)
%fourierWarp_mesh by Murat TAHTALI, (c) 2004
%fourierWarp_mesh warps using Fourier Interpolation according to the
%Input (Is,Js) and Output (Id,Jd) meshes
%USES:
%       warpmesh2shifts.m
%       

if nargin<6,
    silent=0;
end
if nargin<7,
    scl0=1;
end

if nargin<8,
    nowarp=false;
end

if nargin<9,
    Xnowarp=false;
end
if nargin<10,
    Ynowarp=false;
end




[M,N,O]=size(Im);
[mm,nn]=size(Is);

Is1=prepadgrid(Is);
Js1=prepadgrid(Js);
Id1=prepadgrid(Id);
Jd1=prepadgrid(Jd);
[xs,ys,Xs,Ys]=warpmesh2shifts(Is1,Js1,Id1,Jd1,M,N,1);

% Xsr=-real(Xs);
% Ysr=real(Ys);


if silent==0,
figure(333)
subplot(1,2,1)
imshow(Xs,[])

subplot(1,2,2)
imshow(Ys,[])
end

scl=(M*N)/((mm-1)*(nn-1))*scl0;
scl=scl/4;
%Out=warpadfa(Im, Xs, Ys, scl);
Xs=Xs*scl;
Ys=Ys*scl;


if nowarp==false,
    if Xnowarp,
        Xs=Xs*0;
    end
    if Ynowarp,
        Ys=Ys*0;
    end
    flow.m5=Xs;
    flow.m6=Ys;
 %   Out=flow_warp(Im,flow,'cubic');
 s3=size(Im,3);
 if s3>1,
     for k=1:s3,
     Out(:,:,k)=warpadfa(Im(:,:,k),Xs,Ys,4);
     end
 else
    Out=warpadfa(Im,Xs,Ys,4);
 end
else
    Out=[];
end


function [Iss,Jss,t]=grid_meshtemp(M,N,mm,nn,Ax,Ay,Np,Fs,Fcx,Fcy)
%Generates random grid coordinates of mm by nn points onto an image grid of M by N
dm=(M-1)/(mm-1);
dn=(N-1)/(nn-1);

for I=1:mm,
    i=floor((I-1)*dm+1);
    for J=1:nn,
         j=floor((J-1)*dn+1);       
         Js(I,J)=j;
         Is(I,J)=i;
    end
end

Iss(mm,nn,Np)=0;
Jss(mm,nn,Np)=0;
for I=1:mm,
    for J=1:nn,
        if I>1 & I<mm & J>1 & J<nn
            [t,X]=shiftcoh(Ax,Np,Fs,Fcx,1);
            [t,Y]=shiftcoh(Ay,Np,Fs,Fcy,1);
            for k=1:Np,
                Iss(I,J,k)=Is(I,J)+Y(k);
                Jss(I,J,k)=Js(I,J)+X(k);   
            end
        else
            Iss(I,J,1:Np)=Is(I,J);
            Jss(I,J,1:Np)=Js(I,J);   
        end
    end
end


function [t,sf,avr]=shiftcoh(A,N,Fs,Fc,silent)
%SHIFTCOH generates random waveform with the  following specs
%A Magnitude
%N points: the signal is T=N/Fs seconds long
%Fs Sampling frequency
%Fc Cut-off frequency: maximum frequency present in the waveform

dwn=2/Fs;
wn=dwn*Fc;
N1=floor(N*1.05);
t = (1:N1)/Fs;
t=t-(t(1));
s=randn(1,N1);

[b,a] = butter(5,wn);
sf = filter(b,a,s);

%retain last N points:
sf=sf(N1-N+1:N1);
s=s(N1-N+1:N1);
t=t(1:N);
mm=max(abs(sf));
avr=mean(sf);
sf=sf-avr;
sf=sf/mm*A;

avr=mean(sf);

if silent~=1
subplot(2,1,1);
plot(t,s);
xlabel('Time (seconds)'); ylabel('Time waveform');

subplot(2,1,2);
plot(t,sf,t,avr);
xlabel('Time (seconds)');
ylabel('Time waveform');
end


function im2 = warpadfa(im1, xs, ys, scale,blend)
%
% warps image im1 according to shift images xs and ys
%   such that x1 = x2 + scale*xs; and y1 = y2 + scale*ys;
%
%  Corrected for end effects when fractional parts are zero, 3 October 2003
% now fails at boundary using shifts of 1.5 for example - March 2009
% -so....
%AJL - blend keeps the partially shifted pixels from earlier in the
%algorithm. 
% Andrew Lambert, a.lambert@adfa.edu.au

if (nargin < 5) blend = 0; end; % original algorithm
if (nargin < 4) scale = 1; end;

[ny1, nx1] = size(im1);
[ny, nx]=size(xs);
fmult=ny1/ny;

xscale=scale;
yscale=scale;

im2=zeros(ny, nx);
 % slightly faster this way around, was 1:nx
for y2=1:ny % was 1:ny
    for x2=1:nx 
        y11 = fmult*(y2 + yscale*ys(y2, x2));
        x11 = fmult*(x2 + xscale*xs(y2, x2));
        
        y1 = floor(y11);
        yfract = y11-y1;
        x1 = floor(x11);
        xfract = x11-x1;
        
     %   if y1 >= 1 & y1 <= ny1 & x1 >=1 & x1 <= nx1
        if (y1 >= 1) && (y1 < ny1) && (x1 >=1) && (x1 < nx1)
            g11 = im1(y1, x1);
            g12 = im1(y1, x1+1);
            g21 = im1(y1+1, x1);
            g22 = im1(y1+1, x1+1);
            gg2 = (1-xfract)*g21 + xfract*g22;
            gg1 = (1-xfract)*g11 + xfract*g12;
            im2(y2, x2) = ((1-yfract)*gg1 + yfract*gg2) + blend*im2(y2,x2);
%             if xfract == 0 
%                 gg1 = im1(y1, x1);
%             else
%                 g11 = im1(y1, x1);
%                 g12 = im1(y1, x1+1);
%                 gg1 = (1-xfract)*g11 + xfract*g12;
%             end
%             if yfract == 0 
% %                im2(y2, x2) = gg1;
% %                im2(y2, x2) = gg1*(1-blend)+blend*im2(y2,x2);
%                 im2(y2, x2) = gg1 +blend*im2(y2,x2);
%             else
%                 if xfract == 0 
% %                    gg2 = im1(y1+1, x1);
%                     gg2 = im1(y1, x1);
% %                    im2(y2, x2) = (1-yfract)*gg1 + yfract*gg2;
%      %               im2(y2, x2) = ((1-yfract)*gg1 + yfract*gg2)*(1-blend) + blend*im2(y2,x2);
%                     im2(y2, x2) = ((1-yfract)*gg1 + yfract*gg2) + blend*im2(y2,x2);
%                 else
% %                     g21 = im1(y1+1, x1);
% %                     g22 = im1(y1+1, x1+1);
% %                     gg2 = (1-xfract)*g21 + xfract*g22;
%                     g21 = im1(y1, x1);
%                     g22 = im1(y1+1, x1+1);
%                     gg2 = (1-xfract)*g21 + xfract*g22;
% %                    im2(y2, x2) = (1-yfract)*gg1 + yfract*gg2;
% %                    im2(y2, x2) = ((1-yfract)*gg1 + yfract*gg2)*(1-blend) + blend*im2(y2,x2);
%                     im2(y2, x2) = ((1-yfract)*gg1 + yfract*gg2) + blend*im2(y2,x2);
%                 end
%             end
        end
    end
end


function [imOUT,imDeb,imPSF]=avrmovie(mv,st,en,deb)
N=size(mv,2);
if nargin<2
    st=1;
end

if nargin<3,
    en=N;
end

if nargin<4,
    deb=0;
end


[X,map]=frame2im(mv(1));
[m,n]=size(X);
imOUT=double(X)*0;
if en>N
    en=N;
end
NN=en-st+1;
for i=st:en,
    [X,map]=frame2im(mv(i));
    X=double(X);
    imOUT=imOUT+X/NN;
end
imOUT=uint8(imOUT*3);
imOUT=imOUT(:,:,1);
imDeb=imOUT;
if deb>0
    
    INITPSF = ones(deb,deb);
[imDeb imPSF] = deconvblind(imOUT,INITPSF);
else
    imPSF=[];

end


function [OUT]=resample_gen(F,IN)
%INSERT Copyright and reference info from  book!!!!!!!!!!!!!!!!!!!!


INlen=max(size(IN));
OUTlen=INlen;
OUT=IN;
IN(INlen+1)=0;

%Precompute input index for each output pixel
u=1;
inpos(OUTlen+1)=0;
for x=1:OUTlen-1,
    while F(u+1)<x 
        u=u+1;
    end
        inpos(x)=u+(x-F(u))/(F(u+1)-F(u));
end

INSEG=1.0;              %entire input pixel is available
OUTSEG=inpos(2);         %# input pixels that map onto 1 output pixel
SIZFAC=OUTSEG;
INSFAC=OUTSEG;          %inverse scale factor
acc=0;                  %clear accumulator


%Compute all output pixels

x=1;
v0=IN(x);
v1=IN(x+1);
x=x+2;
y=2;
u=2;
while u<=OUTlen,

       %Use linear interpolation for reconstruction

       intensity=INSEG*v0+(1-INSEG)*v1;       

       %INSEG<OUTSEG: input pixel is entirely consume before output pixel
       if INSEG<OUTSEG,
            acc=acc+intensity*INSEG;        %accumulate weighted contribution
            OUTSEG=OUTSEG-INSEG;            %INSEG portion has been filled
            INSEG=1;                        %new input pixel will be available
            v0=v1;
            
            v1=IN(x);
            x=x+1;                          %index into next input pixel
            
        else        %INSEG>=OUTSEG: input pixel is not entirely consumed before output pixel    
            acc=acc+intensity*OUTSEG;       %accumulate weighted contribution
            acc=acc/SIZFAC;
            OUT(y)=min([acc 255]);              %init output with normalised accumulator
            y=y+1;
            acc=0;                          %reset accumulator for next output pixel
            INSEG=INSEG-OUTSEG;             %OUTSEG portion of input has been used
                                      %index into next output pixel
            
            OUTSEG=inpos(u+1)-inpos(u);     %init spatially-varying INSFAC
            SIZFAC=OUTSEG;                  %init spatially-varying SIZFAC      ??????????????????
            u=u+1;
        end
end
u=u;


%WARP_MESH  Two-pass mesh warping based on
%"A Two-Pass Mesh Warping Algorithm for Object Transformation and Image Interpolation"
%by Douglas B. Smythe
%ILM Technical Memo #1030, Computer Graphics Department, Lucasfilm Ltd., 1990.
%
%MATLAB transcoding and adaptation by Murat TAHTALI, ADFA, 2002.
function [OUT,TMP]=warp_meshlin(IN,Is,Js,Id,Jd,strt)
%strt = 1 then the source grid is straight
if exist('strt')==0
    strt=0;
end
[IN_h,IN_w]=size(IN);
[T_h,T_w]=size(Is);



%FIRST PASS (phase one): create tables Ts and Ti for j-intercepts of
%vertical splines in S and I. Tables have T_w columns of height IN_h
%indices used to sample vertical splines
%for y=1:IN_h,
 %   indx(y)=y;
 %end
indx=[1:IN_h]'; %indices used to sample vertical splines
%Visit each vertical spline
for j=1:T_w,
        xrow1=Js(:,j); %jValS=Js(:,j);
        yrow1=Is(:,j); %iValS=Is(:,j); 
        
        xrow2=Jd(:,j); %jValD=Jd(:,j);
        yrow2=Id(:,j); %iValD=Id(:,j);
        
        map1=interp1(yrow1,xrow1,indx);
        map2=interp1(yrow2,xrow2,indx);
        
        
        
    
        
        
    
    %scan convert vertical splines of S and I
    %ispline_gen(yrow1,xrow1,T_h,indx,map1,IN_h);
    %ispline_gen(yrow2,xrow2,T_h,indx,map2,IN_h);
    %using MATLAB's built-in SPLINE function instead of ispline_gen
    %store resampled rows back into columns
     %Ts(:,j)=spline(iValS,jValS,indx);
     %Ti(:,j)=spline(iValD,jValD,indx);    
     Ts(:,j)=map1;
     Ti(:,j)=map2;
     
end

%FIRST PASS (phase two): warp j using Ts and Ti. TMP holds intermediate image

indx=[1:IN_w]; %indices used to sample horizontal spline
for i=1:IN_h,   %visit each row
    
    x1=Ts(i,:);
    x2=Ti(i,:);
    map1=interp1(x1,x2,indx);
    
%    j1=Ts(i,:);
%    j2=Ti(i,:);
%    map1=spline(j2,j1,indx);
    
    %Resample source row based on map1
    src=IN(i,:);
    dst=resample_gen(map1,src);
%    spline(indx,src,map1);
    TMP(i,:)=dst;
end
%OUT=TMP;
%return
clear Ts Ti map1 map2 dst

%SECOND PASS (phase one): create tables Ti and Td for i-intercepts of
%horizontal splines in I and D. Tables have T_h rows of width IN_w

indx=[1:IN_w]; %indices used to sample horizontal spline
for i=1:T_h,    %visit each horizontal spline
    %scan convert horizontal splines
    
    x1=Js(i,:);
    y1=Is(i,:);
    
    x2=Jd(i,:);
    y2=Id(i,:);
    
    
    
%    j1=Js(i,:);
%    i1=Is(i,:);
%    j2=Jd(i,:);
%    i2=Id(i,:);

    Ti(i,:)=interp1(x1,y1,indx);
    Td(i,:)=interp1(x2,y2,indx);

    
%    Ti(i,:)=spline(j1,i1,indx);
%    Td(i,:)=spline(j2,i2,indx);
    
   
end

%SECOND PASS (phase two): warp y using Ti and Td
indx=[1:IN_h];
for j=1:IN_w
%    jrow1=Ti(:,j);
%    irow1=Td(:,j);
    xrow1=Ti(:,j)';
    yrow1=Td(:,j)';

   %fit spline to y-intercepts; resample over all rows
   map1=interp1(xrow1,yrow1,indx);
   
   %resample intermediate image column based on map1
   
   src=TMP(:,j)';
   dst=resample_gen(map1,src);
%   dst=spline(indx,src,map1);

   OUT(:,j)=dst';
end
  
function [ out ] = isvobj( obj )
out=0;
if isobject(obj),
    lst=fieldnames(obj);
    N=length(lst);
    for k=1:N,
        if strcmp(lst{k},'VideoFormat'),
            out=1;
        end
    end
end


