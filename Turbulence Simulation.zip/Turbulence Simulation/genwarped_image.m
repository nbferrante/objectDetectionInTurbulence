%DEMO script to generate a video sequence from temporally shifted grid points

clear all
close all

M=13        %grid points in the y-direction
N=13        %grid points in the x-direction
cycle=0     %no cycling and the first frame is the original frame
Np=60       %number of frames to generate
Fs=25       %Sampling rate
Fcx=5       %Max frequency of wander in the x-dir
Fcy=5       %Max frequency of wander in the y-dir
Ax=2        %Max pixel wander in the x-dir
Ay=Ax        %Max pixel wander in the y-dir
method='f'  %Fourier interpolation, alternative linear 'l' is painfully slow!

extension=50; %Number of pixels to extend the original image

%[im,map]=imread('lena256.tif');
%im1=ImExtend(ind2gray(im,map),extension);
basename='mires';
im=imread('mires.tif');
im1=ImExtend(im,extension);
%im1=ind2gray(im,map);
[m,n]=size(im1);

[Mv,Is,Js,t]=genwarpedseq(im1,method,extension,Np,Fs,Fcx,Fcy,Ax,Ay,M,N,cycle,0);
lenaseq.Mv=Mv;
lenaseq.Is=Is;
lenaseq.Js=Js;
lenaseq.t=t;
lenaseq.Np=Np; 
lenaseq.Fs=Fs; 
lenaseq.Fcx=Fcx;
lenaseq.Fcy=Fcy;
lenaseq.Ax=Ax;
lenaseq.Ay=Ay;
lenaseq.M=M;
lenaseq.N=N;
lenaseq.cycle=cycle;

%save Lena_seq lenaseq    %Save as mat file containing all data in structure form, including the raw random walk
name=sprintf('%s_%d.avi',basename,Ax);
moviesave(lenaseq.Mv,name,25) %Save as a playable AVI video at 25fps.
seq=Mv2cube(lenaseq.Mv,extension);
name=sprintf('%s_%d.mat',basename,Ax);
save(name,'seq');
%figure

%movie(Mv,1)