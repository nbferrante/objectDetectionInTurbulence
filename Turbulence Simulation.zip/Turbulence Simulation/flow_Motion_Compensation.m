function [flow_corrected, Translation_Field, Rotation_Field] = flow_Motion_Compensation(flow)
    %==========================================================================
%
% [flow_corrected, Translation_Field, Rotation_Field] = flow_Motion_Compensation(flow)
%
% This function performs global motion compensation for a given flow.  The
% model utilized assumes that global motion is induced by translational and
% rotational motion only.  No divergence is assumed for simplicity.
%
% Input arguments:
% flow  : row x column x 2  optical flow where the first field presented is
% the x directional movment and the second the y.
%
% Output arguments:
% flow_corrected    : Corrected global flow
% Translation_Field : Global Translation Field
% Rotation_Field    : Rotation Translational Field
%
% Author: N.Ferrante
% Institution: SDSU - Department of Mathematics & Statistics
% email: nferrante@sdsu.edu
% Date: July, 24th, 2016
%
%==========================================================================

    % The median value for each independent direction is taken and is assumed
    % to be the "best" approximation for the global translational movement
        [row, col, ~] = size(flow);
        tmpx = flow(:, :, 1);
        tmpy = flow(:, :, 2);
        x_ave = mean(tmpx(:));
        y_ave = mean(tmpy(:));
        Translation_Field = zeros(size(flow));
        
        Translation_Field(:, :, 1) = x_ave*ones(row, col);
        Translation_Field(:, :, 2) = y_ave*ones(row, col);
        
        flow_corrected = flow - Translation_Field;


        F = zeros(row, col, 2);

    % Build the points in which the rotation field will live.  We assume that
    % the rotation field will be "centered" at the middle of the image and the
    % magnitude of the flow will correspond to the angular velocity of the
    % vector field.  This angular velocity is computed by way of the curl
    
        x_frame = -(row - 1)/2:(row - 1)/2;
        y_frame = -(col - 1)/2:(col - 1)/2;
        for ii = 1:length(x_frame)
        for jj = 1:length(y_frame)
            F(ii, jj, 2) = -y_frame(jj);
            F(ii, jj, 1) = x_frame(ii);
        end
        end

        % Angular velocity field is computed by way of the curl
        
        [~, thetaDot_field] = curl(flow_corrected(:, :, 1), flow_corrected(:, :, 2));
        
        % Median angle is taken to be the "best" approximation for the global
        % turning of the flow.
        
        theta_dot_ave = median(thetaDot_field(:));

        Rotation_Field = -F*theta_dot_ave;

        % The corrected flow is then added to the optical flow in order to
        % corect any turning in the image
        flow_corrected = flow_corrected - Rotation_Field;

%         compensated_color_flow = get_color_flow(flow_corrected(:, :, :));
%         C_compensated_flow(:, :, :) = compensated_color_flow;
        

end