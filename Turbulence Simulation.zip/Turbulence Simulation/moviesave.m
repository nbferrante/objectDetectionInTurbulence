function moviesave(mv,fname,fps)
%moviesave, Murat Tahtali (2007), UNSW Canberra
%           m.tahtali@adfa.edu.au
if nargin<3,
    fps=15;
end
movie2avi(mv,fname,'compression','none','fps',fps)
