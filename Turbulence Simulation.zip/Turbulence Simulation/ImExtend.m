function f=ImExtend(im,b)

f=zeros(2*b+size(im,1),2*b+size(im,2));

f(b+1:b+size(im,1),b+1:b+size(im,2))=im;
f(1:b,:)=f(2*b:-1:b+1,:);
f(end-b+1:end,:)=f(end-b:-1:end-2*b+1,:);
f(:,1:b)=f(:,2*b:-1:b+1);
f(:,end-b+1:end)=f(:,end-b:-1:end-2*b+1);
