function seq=Mv2cube(Mv,b)

%seq=uint8(zeros(size(Mv(1).cdata,1)-2*b,size(Mv(1).cdata,2)-2*b,length(Mv)-10));
seq=uint8(zeros(size(Mv(1).cdata,1),size(Mv(1).cdata,2),length(Mv)-10));

for t=11:length(Mv)
%   seq(:,:,t-10)=uint8(ImCrop(Mv(t).cdata,b)); 
   seq(:,:,t-10)=uint8(Mv(t).cdata); 
end