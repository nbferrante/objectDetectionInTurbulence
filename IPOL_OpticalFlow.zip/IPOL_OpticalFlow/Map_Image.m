function v=Map_Image(f,vecX,vecY)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Morphing of the image via given vector field
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[X,Y]=meshgrid(1:size(f,2),1:size(f,1));

%Set the coordinates where to map
XX=X+vecX(:,:);
YY=Y+vecY(:,:);

%check if the coordinates go outside the image domain
XX(XX<1)=1;
XX(XX>size(f,2))=size(f,2);
YY(YY<1)=1;
YY(YY>size(f,1))=size(f,1);

%maps the image using linear interpolation
v(:,:)=interp2(f(:,:),XX,YY,'linear');    
