function [seq] = vid2seq(in)
% Example
% Resizing Reslution
%   in.res = .4;
% 
% Filename to load: in.name      ='./Simulated_Turbulence/seq_2/seq_2';
% 
% File type (avi, mp4, ...): in.type      ='.MP4';
% 
% Total number of frames to load: in.N_frames   = 100;
% 
% Starting Frame: in.start_val  = 200;
% 
% How many files to skip: in.jump       = 2;


v = VideoReader([in.name, in.type]);

res = in.res;
N_frames = in.N_frames;
start_val = in.start_val;
seq = zeros(res*v.Height, res*v.Width, N_frames);
n = 0;
for ii = 1:in.jump:in.jump*N_frames
    n=n+1;
    seq(:, :, n) = imresize(im2double(rgb2gray(read(v, ii + start_val))), res);
end

end