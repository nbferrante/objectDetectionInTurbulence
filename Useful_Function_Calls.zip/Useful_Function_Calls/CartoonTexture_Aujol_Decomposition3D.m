function [u,v]=CartoonTexture_Aujol_Decomposition3D(in,lambda,mu,Niter,PNiter,alpha)

%==========================================================================
%
% function [u,v]=CartoonTexture_Aujol_Decomposition3D(in,lambda,mu,Niter,PNiter)
%
% This function performs the 3D Cartoon+Texture decomposition (TV-G) based on
% the Chambolle's projector as used in the Aujol PhD and related papers.
%
% Input arguments:
% in : input cube
% lambda : regularization parameter (0.1)
% mu : upper bound for the texture (G) norm (0.1)
% Niter : maximum number of iterations  (5)
% PNiter : number of iteration for Chambolle's projector (20)
%
% Output arguments:
% u : cartoon part
% v : texture part
%
% Author: J.Gilles
% Institution: SDSU - Department of Mathematics & Statistics
% email: jgilles@mail.sdsu.edu
% Date: July, 21th, 2016
%
%==========================================================================

u=zeros(size(in));
v=zeros(size(in));
up=in;
vp=in;

tol=1e-6*norm(in(:),'fro');

n=0;
m(n+1)=max(norm(u(:)-up(:),'fro'),norm(v(:)-vp(:),'fro'));
while (n<Niter) && (m(n+1)>tol)
   n=n+1;
   up=u;
   vp=v;
   
   v=ChambolleProjector3D(in-u,mu,PNiter,alpha);
   u=in-v-ChambolleProjector3D(in-v,lambda,PNiter,alpha);
   
   m(n+1)=max(norm(u(:)-up(:),'fro'),norm(v(:)-vp(:),'fro'));
end
