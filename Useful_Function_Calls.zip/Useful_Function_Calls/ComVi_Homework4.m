close all

numFrames = size(f,3);
height = size(f,1);
width =size(f,2);

%% Compute Background
Imback=sum(f,3)/numFrames;

figure
for i=2:numFrames
    thr=0.1; 
    % Background substraction and thresholding
    DiffT=abs(f(:,:,i)-Imback)>thr;
    % Opening to remove small objects
    DiffT=bwareaopen(DiffT,100,8);
    subplot(1,2,1);imshow(DiffT,[]);

    % Detect connected components
    CCT=bwconncomp(DiffT);
    % Extract bounding box of each connected component
    ST=regionprops(CCT,'BoundingBox');
    
    % Plot result
    subplot(1,2,2);imshow(f(:,:,i),[]);
    for k=1:numel(ST)
        BB0=ST(k).BoundingBox;
        rectangle('position',[BB0(1), BB0(2), BB0(3), BB0(4)],'EdgeColor','r');    
    end
    pause(0.1);
end



