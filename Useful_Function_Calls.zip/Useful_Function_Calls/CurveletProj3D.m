function rec=CurveletProj3D(f,lambda)

%==========================================================================
%
% function [rec1,rec2]=CurveletProj3D(f,lambda)
%
% This function performs the curvelet transform of each space-time
% components of the input vector field, do a soft thresholding of the
% curvelet coefficients and then reconstruct the vector field.
%
% Input:
%   -f: input vector field 
%   -lambda: threshold
%
% Output:
%   -rec: processed vector field
%
% Author: J.Gilles (San Diego State University)
% Date: 12/27/2016
% Version: 1.0
%==========================================================================

%we normalize the input vector field
MINf=min(f(:));
MAXf=max(f(:));
f=(f-MINf)/(MAXf-MINf);

%we process the first component
fdctnormflow=fdct3d_forward(squeeze(f(:,:,1,:)));
shr=ShrinkComplexCurvelet(fdctnormflow,lambda);
rec1=fdct3d_inverse(shr);
%disp('1st component ok')

%we process the second component
fdctnormflow=fdct3d_forward(squeeze(f(:,:,2,:)));
shr=ShrinkComplexCurvelet(fdctnormflow,lambda);
rec2=fdct3d_inverse(shr);
%disp('2nd component ok')

%we reconstruct the final vector field
rec=zeros(size(f));
rec(:,:,1,:)=rec1;
rec(:,:,2,:)=rec2;
rec=real(rec);

rec=(MAXf-MINf)*rec+MINf;