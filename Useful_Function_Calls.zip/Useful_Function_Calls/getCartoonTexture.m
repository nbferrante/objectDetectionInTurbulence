function [u, v] = getCartoonTexture(flow, mu, lambda, Niter, method)

if ~strcmp(method, 'wavelet') && ~strcmp(method, 'curvelet')
    method = 'wavelet (default)';
end

HeadMessage = ['Cartoon+Texture with the ', method, ' transform'];
disp('Starting decomposition...')
disp(HeadMessage)
u=zeros(size(flow));
v=zeros(size(flow));


for n=1:Niter
   tic   
   %% Decomposition Method
   tmp=flow-u;
   switch method
       case 'wavelet'
            v=tmp-CpxWaveletProj3D(tmp,2*mu);
            u=CpxWaveletProj3D(flow-v,2*lambda);
       case 'curvelet'
            v=tmp-CpxCurveletProj3D(tmp,2*mu);
            u=CpxCurveletProj3D(flow-v,2*lambda);
       otherwise
           v=tmp-CpxWaveletProj3D(tmp,2*mu);
           u=CpxWaveletProj3D(flow-v,2*lambda);
   end
   %% Timer
   iter_time=toc;
   minutes=floor((Niter - n)*iter_time/60);
   seconds=floor((Niter - n)*iter_time - minutes*60);
   c=clock;
   clc
   disp(HeadMessage)
   if c(5) < 10
    fprintf('At %d:0%d,\nthere are %d of %d iterations completed\n %d minutes %d seconds remain\n',c(4),c(5),n,Niter,minutes,seconds);
   else
       fprintf('At %d:%d,\nthere are %d of %d iterations completed\n %d minutes %d seconds remain\n',c(4),c(5),n,Niter,minutes,seconds);
   end
end
