function F = Chen_Background_Substraction(f,Ninit,G)

%constants as fixed in the paper
O=0.05*max(f(:));
%G=0.1;
alpha=0.97;
se=strel('disk',3);

%initialize foreground
F=zeros(size(f));

%Initialize the background
B=median(f(:,:,1:Ninit),3);

%compute initial difference, threshold and foreground
D=abs(f(:,:,1)-B);
T=G*D+O;
tmp=zeros(size(f,1),size(f,2));
tmp(D>T)=1;
F(:,:,1)=imclose(imopen(tmp,se),se);

for t=2:size(f,3)
    B=alpha*B+(1-alpha)*f(:,:,t);
    D=(1-alpha)*D+alpha*abs(f(:,:,t)-B);
    T=G*D+O;
    tmp=zeros(size(f,1),size(f,2));
    tmp(D>T)=1;
    F(:,:,t)=imclose(imopen(tmp,se),se);
end