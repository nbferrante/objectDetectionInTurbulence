function rec=CpxCurveletProj3D(f,lambda)

%==========================================================================
%
% function [rec1,rec2]=CpxCurveletProj3D(f,lambda)
%
% This function performs the curvelet transform of the complex space-time
% input vector field, do a soft thresholding of the
% curvelet coefficients and then reconstruct the vector field.
%
% Input:
%   -f: input vector field 
%   -lambda: threshold
%
% Output:
%   -rec: processed vector field
%
% Author: J.Gilles (San Diego State University)
% Date: 12/27/2016
% Version: 1.0
%==========================================================================

%we normalize the input vector field
MINf=min(f(:));
MAXf=max(f(:));
f=(f-MINf)/(MAXf-MINf);

%create the complex field
f=complex(squeeze(f(:,:,1,:)),squeeze(f(:,:,2,:)));

%we process the complex field
fdctnormflow=fdct3d_forward(f);
shr=ShrinkComplexCurvelet(fdctnormflow,lambda);
rec1=fdct3d_inverse(shr);

%we reconstruct the final vector field
rec=zeros(size(f,1),size(f,2),2,size(f,3));
rec(:,:,1,:)=real(rec1);
rec(:,:,2,:)=imag(rec1);

rec=(MAXf-MINf)*rec+MINf;