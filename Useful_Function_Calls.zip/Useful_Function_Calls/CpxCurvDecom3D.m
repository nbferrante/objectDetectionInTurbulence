function [u,v]=CpxCurvDecom3D(f,mu,lambda,Niter)

u=zeros(size(f));
v=zeros(size(f));
disp('First iteration is starting')
for n=1:Niter
   tic
   tmp=f-u;
   
   %% Decomposition Method
   v=tmp-CpxCurveletProj3D(tmp,2*mu);
   u=CpxCurveletProj3D(f-v,2*lambda);
   %% Timer
   iter_time = toc;
   minutes = floor((Niter - n)*iter_time/60);
   seconds = floor((Niter - n)*iter_time - minutes*60);
   c = clock;
   if c(5) < 10
    fprintf('At %d:0%d, \nthere are %d of %d iterations completed\n %d minutes %d seconds remain\n',c(4), c(5),n, Niter, minutes, seconds);
   else
       fprintf('At %d:%d, \nthere are %d of %d iterations completed\n %d minutes %d seconds remain\n',c(4), c(5),n, Niter, minutes, seconds);
   end
end
end