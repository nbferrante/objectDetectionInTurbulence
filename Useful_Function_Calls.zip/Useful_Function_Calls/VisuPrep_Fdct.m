function visu=VisuPrep_Fdct(visu)

%visu=cell(size(f));

for l=1:length(visu)
    fprintf('====== l=%d ======\n',l);
%   visu{l}=cell(size(f{l}));
   for t=1:length(visu{l})
       fprintf('t=%d \n',t);
            tmp=abs(visu{l}{t});
            visu{l}{t}=(tmp-min(tmp(:)))/(max(tmp(:))-min(tmp(:)));
   end
end