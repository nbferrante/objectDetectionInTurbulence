function SaveTile2VideoWOrig2(name,A,B)

%==========================================================================
% function SaveTile2Video(name,A,B)
%
% This function tiles the two sequences A and B in the order 
%                          A B
% and saves it in an avi video file
%
% Inputs:
%   -name: name of the avi file (e.g. 'video.avi')
%   -A,B: the two input sequences (must in uint8 format)
%
%==========================================================================

%we normalize the input sequence in [0,1]
% A=(A-min(A(:)))/(max(A(:))-min(A(:)));
% B=(B-min(B(:)))/(max(B(:))-min(B(:)));
% 
%test if we have a grayscale we turn it to a 4D matrix

if length(size(A))==3
   tmp=A;
   A=zeros(size(A,1),size(A,2),3,size(A,3),'uint8');
   A(:,:,1,:)=tmp(:,:,:);
   A(:,:,2,:)=tmp(:,:,:);
   A(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(B))==3
   tmp=B;
   B=zeros(size(B,1),size(B,2),3,size(B,3),'uint8');
   B(:,:,1,:)=tmp(:,:,:);
   B(:,:,2,:)=tmp(:,:,:);
   B(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end


%Create the avi file frame by frame
v = VideoWriter(name);
open(v);
set(gca,'nextplot'); 
figure(1);
tile=zeros(size(A,1),size(A,2)+size(B,2),3,'uint8');
for ii = 1:size(A,4)
    tile(:,:,:) = [A(:,:,:,ii), B(:,:,:,ii)];
    imshow(tile(:,:,:),[]);
    frame = getframe;
    writeVideo(v,frame);
end

close(1);
close(v);