function [] = seq2vid(A, name)
if nargin == 1
    [file,path,~] = uiputfile('file.avi');
    if file == 0
        disp('No file selected')
        return;
    end
    name = [path,file];
end
if nargin == 2
    if ~strcmp(name(end-3), '.')
        name = [name, '.avi'];
    end
end
v = VideoWriter(name);
open(v);
if length(size(A))==3
    for ii = 1:size(A,3)
       img = A(:,:,ii);
       writeVideo(v,img);
    end
else
    for ii = 1:size(A,4)
       img = A(:,:,:,ii);
       writeVideo(v,img);
    end
end
close(v);