%% Moving target detection in turbulence (assume that the sequence is stored in the variable f)

% Compute the movement flow between successive images
Demonflow=zeros(size(f,1),size(f,2),2,size(f,3)-1);
% Cdemon=zeros(size(f,1),size(f,2),3,size(f,3)-1);
%angflow=zeros(size(f,1),size(f,2),size(f,3)-1);
for t=1:size(f,3)-1
     [Demonflow(:,:,:,t),~]=imregdemons(f(:,:,t+1),f(:,:,t));
%      Cdemon(:,:,:,t)=SeqflowToColor(Demonflow(:,:,1,t),Demonflow(:,:,2,t));
% %    angflow(:,:,t)=Miguel_2D_unwrapper(single(atan2(flow(:,:,2,t),flow(:,:,1,t))));
end

%angflownorm=(angflow-min(angflow(:)))/(max(angflow(:))-min(angflow(:)));

% normflow=(flow-min(flow(:))/(max(flow(:))-min(flow(:))));
% fdctnormflow1=fdct3d_forward(squeeze(normflow(:,:,1,:)));
% shr1=ShrinkComplexCurvelet(fdctnormflow1,30);
% rec1=fdct3d_inverse(shr1);
% 
% fdctnormflow2=fdct3d_forward(squeeze(normflow(:,:,2,:)));
% shr2=ShrinkComplexCurvelet(fdctnormflow2,30);
% rec2=fdct3d_inverse(shr2);


%% Simple thresholding of curvelet coefficients
%rec=CurveletProj3D(flow,30);
%CseqP=SeqflowToColor(squeeze(rec(:,:,1,:)),squeeze(rec(:,:,2,:)));

%% Simple thresholding of curvelet coefficients - COMPLEX case
% rec=CpxCurveletProj3D(flow,30);
% CseqP=SeqflowToColor(squeeze(rec(:,:,1,:)),squeeze(rec(:,:,2,:)));
% implay(CseqP);

%% Curvelet decomposition
% [u,v]=CurvDecom3D(flow,1,1,5);
% CseqU=SeqflowToColor(squeeze(u(:,:,1,:)),squeeze(u(:,:,2,:)));
% CseqV=SeqflowToColor(squeeze(v(:,:,1,:)),squeeze(v(:,:,2,:)));
% implay(CseqU);implay(CseqV);

%% Curvelet decomposition - COMPLEX case
[Demonu,Demonv]=CpxCurvDecom3D(Demonflow,1,1,5);
CDemonU=SeqflowToColor(squeeze(Demonu(:,:,1,:)),squeeze(Demonu(:,:,2,:)));
CDemonV=SeqflowToColor(squeeze(Demonv(:,:,1,:)),squeeze(Demonv(:,:,2,:)));
%implay(CseqU);implay(CseqV);
disp('Demon ok')


HSflow = Sequence_HornSchunck_flow(f, 20, 0.5, 0.001 ,10, 10, 150);
[HSu,HSv]=CpxCurvDecom3D(HSflow,1,1,5);
CHSU=SeqflowToColor(squeeze(HSu(:,:,1,:)),squeeze(HSu(:,:,2,:)));
CHSV=SeqflowToColor(squeeze(HSv(:,:,1,:)),squeeze(HSv(:,:,2,:)));
disp('HS ok')

tvl1flow = Sequence_TVL1_flow(f, 0.25, 0.15, 0.3, 0.5, 0.01, 5, 100);
[TVL1u,TVL1v]=CpxCurvDecom3D(tvl1flow,1,1,5);
CTVL1U=SeqflowToColor(squeeze(TVL1u(:,:,1,:)),squeeze(TVL1u(:,:,2,:)));
CTVL1V=SeqflowToColor(squeeze(TVL1v(:,:,1,:)),squeeze(TVL1v(:,:,2,:)));
disp('TVL1 ok')

%% BV-G decomposition
% [u,v]=BVGDecomp3D(flow,0.01,100,5,20,1);
% MINf=min(flow(:));
% MAXf=max(flow(:));
% u=(MAXf-MINf)*u+MINf;
% v=(MAXf-MINf)*v+MINf;
% CseqU=SeqflowToColor(squeeze(u(:,:,1,:)),squeeze(u(:,:,2,:)));
% CseqV=SeqflowToColor(squeeze(v(:,:,1,:)),squeeze(v(:,:,2,:)));
% implay(CseqU);implay(CseqV);
