function SaveColorSeq2Video(f,name)

f=255*(f-min(f(:)))/(max(f(:))-min(f(:)));

v = VideoWriter(name);
open(v);
set(gca,'nextplot'); 
figure(1);
tile=zeros(size(f,1),size(f,2),3,'uint8');
for ii = 1:size(f,4)
    tile(:,:,:) = f(:,:,:,ii);
    imshow(tile(:,:,:),[]);
    frame = getframe;
    writeVideo(v,frame);
end

close(1);
close(v);