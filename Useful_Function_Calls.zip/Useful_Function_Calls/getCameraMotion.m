function [M] = getCameraMotion(flow, method)
if ~strcmp(method, 'polynomial') && ~strcmp(method, 'gaussian') && ~strcmp(method, 'analytic')
    method = 'gaussian';
end
M = zeros(size(flow));
[row, col, ~] = size(flow);
switch method
    case 'polynomial'
        %% Polynomial fit
        for kk=1:size(flow,4)
            flow(:,:,1,kk)=imgaussfilt(flow(:,:,1,kk),[round(row/7),round(col/7)]);
            flow(:,:,2,kk)=imgaussfilt(flow(:,:,2,kk),[round(row/7),round(col/7)]);
        end

        for frame = 1:size(flow, 4)

        fx=flow(:, :, 1, frame);
        fy=flow(:, :, 2, frame);

        [YY, XX] = ndgrid((row:-1:1) - row/2, (1:col) - col/2);
        I=abs(fx) < median(abs(fx(:))) + 1.5*iqr(abs(fx(:))); 

        x=XX(I);
        y=YY(I);
        ff=fx(I);

        fit_x=fit([x, y], ff,'poly22');
        M_poly_x=reshape(feval(fit_x, [XX(:), YY(:)]), [row, col]);

        I=abs(fy) < median(abs(fy(:))) + 1.5*iqr(abs(fy(:))); 

        x=XX(I);
        y=YY(I);
        ff=fy(I);

        fit_y=fit([x, y], ff,'poly22');
        M_poly_y=reshape(feval(fit_y,[XX(:), YY(:)]),[row,col]);

        M(:,:,1,frame)=M_poly_x;
        M(:,:,2,frame)=M_poly_y;
        end
    case 'gaussian'
        %% Gaussian fit
        for kk=1:size(flow,4)
            M(:,:,1,kk)=imgaussfilt(flow(:,:,1,kk),[round(row/7),round(col/7)]);
            M(:,:,2,kk)=imgaussfilt(flow(:,:,2,kk),[round(row/7),round(col/7)]);
        end

    case 'analytic'
        %% Analytical fit
        foc=1;

        for frame=1:size(flow,4)
            f=flow(:,:,:,frame);

            v_x=f(:,:,1);
            v_y=f(:,:,2);
            [XX,YY]=meshgrid(-col/2+.5:col/2-.5,-row/2+.5:row/2-.5);

            v_x_x=diffIm(v_x,2);
            v_x_xx=diffIm(v_x_x,2);
            v_x_y=diffIm(v_x,1);
            v_x_yy=diffIm(v_x_y,1);


            v_y_x=diffIm(v_y,2);
            v_y_xx=diffIm(v_y_x,2);
            v_y_y=diffIm(v_y,1);
            v_y_yy=diffIm(v_y_y,1);

            Tz= 0.5*imAve(v_x_x + v_y_y);
            ox= 0.5*imAve(v_y_yy);
            oy=0.5*imAve(v_x_xx);
            oz=-0.5*imAve((v_y_x - v_x_y));
            foc0=foc;
            Tx=imAve(- oy*(foc^2 + XX.^2)) - imAve(f(:,:,1));
            Ty=imAve(- ox*(foc^2 + YY.^2)) - imAve(f(:,:,2));

            flow_x=Tz*XX - Tx + ox*XX.*YY - oy*(foc^2 + XX.^2) + oz*YY;
            flow_y=Tz*YY - Ty + ox*(foc^2 + YY.^2) - oy*XX.*YY - oz*XX;


            M(:,:,1,frame)=flow_x;
            M(:,:,2,frame)=flow_y;

        end

end