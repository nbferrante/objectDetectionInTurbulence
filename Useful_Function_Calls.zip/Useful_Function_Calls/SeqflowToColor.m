function cseq=SeqflowToColor(u,v)

%cseq=cell(1,size(u,3));
cseq=zeros(size(u,1),size(u,2),3,size(u,3),'uint8');
for k=1:size(u,3)
%   cseq{k}=flowToColor(u(:,:,k),v(:,:,k));
    cseq(:,:,:,k)=flowToColor(u(:,:,k),v(:,:,k),1);
end

