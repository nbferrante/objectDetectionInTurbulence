function [u,v]=BVGDecomp3D(f,lambda,mu,Niter,PNiter,alpha)

MINf=min(f(:));
MAXf=max(f(:));
f=(f-MINf)/(MAXf-MINf);

[u1,v1]=CartoonTexture_Aujol_Decomposition3D(squeeze(f(:,:,1,:)),lambda,mu,Niter,PNiter,alpha);
[u2,v2]=CartoonTexture_Aujol_Decomposition3D(squeeze(f(:,:,2,:)),lambda,mu,Niter,PNiter,alpha);

u=zeros(size(f));
v=zeros(size(f));

u(:,:,1,:)=u1;
u(:,:,2,:)=u2;
v(:,:,1,:)=v1;
v(:,:,2,:)=v2;
