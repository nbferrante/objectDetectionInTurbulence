function [CTVL1U] = get_color_flow(seq)
    CTVL1U=SeqflowToColor(squeeze(seq(:,:,1,:)),squeeze(seq(:,:,2,:)));
end