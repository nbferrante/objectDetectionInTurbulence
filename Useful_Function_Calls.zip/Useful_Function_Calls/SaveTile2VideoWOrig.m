function SaveTile2VideoWOrig(name,orig,A,B,C,D)

%==========================================================================
% function SaveTile2Video(name,A,B,C,D)
%
% This function tiles the original sequence, and the four sequences A,B,C, and D in the order 
%                       Orig 0
%                          A B
%                          C D
% and saves it in an avi video file
%
% Inputs:
%   -name: name of the avi file (e.g. 'video.avi')
%   -A,B,C,D: the four input sequences (must in uint8 format)
%
%==========================================================================

%we normalize the input sequence in [0,1]
% A=(A-min(A(:)))/(max(A(:))-min(A(:)));
% B=(B-min(B(:)))/(max(B(:))-min(B(:)));
% C=(C-min(C(:)))/(max(C(:))-min(C(:)));
% D=(D-min(D(:)))/(max(D(:))-min(D(:)));
% 
%test if we have a grayscale we turn it to a 4D matrix

if length(size(orig))==3
   tmp=orig;
   orig=zeros(size(orig,1),size(orig,2),3,size(orig,3),'uint8');
   orig(:,:,1,:)=tmp(:,:,:);
   orig(:,:,2,:)=tmp(:,:,:);
   orig(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(A))==3
   tmp=A;
   A=zeros(size(A,1),size(A,2),3,size(A,3),'uint8');
   A(:,:,1,:)=tmp(:,:,:);
   A(:,:,2,:)=tmp(:,:,:);
   A(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(B))==3
   tmp=B;
   B=zeros(size(B,1),size(B,2),3,size(B,3),'uint8');
   B(:,:,1,:)=tmp(:,:,:);
   B(:,:,2,:)=tmp(:,:,:);
   B(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(C))==3
   tmp=C;
   C=zeros(size(C,1),size(C,2),3,size(C,3),'uint8');
   C(:,:,1,:)=tmp(:,:,:);
   C(:,:,2,:)=tmp(:,:,:);
   C(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(D))==3
   tmp=D;
   D=zeros(size(D,1),size(D,2),3,size(D,3),'uint8');
   D(:,:,1,:)=tmp(:,:,:);
   D(:,:,2,:)=tmp(:,:,:);
   D(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

if length(size(orig))==3
   tmp=orig;
   orig=zeros(size(orig,1),size(orig,2),3,size(orig,3),'uint8');
   orig(:,:,1,:)=tmp(:,:,:);
   orig(:,:,2,:)=tmp(:,:,:);
   orig(:,:,3,:)=tmp(:,:,:);
   clear tmp;
end

empty = zeros(size(A), 'uint8');

%Create the avi file frame by frame
v = VideoWriter(name);
open(v);
set(gca,'nextplot'); 
figure(1);
tile=zeros(size(A,1)+size(C,1)+size(orig,1),size(orig,2)+size(empty,2),3,'uint8');
for ii = 1:size(A,4)
    tile(:,:,:) = [orig(:,:,:,ii), empty(:,:,:,ii); A(:,:,:,ii), B(:,:,:,ii); C(:,:,:,ii), D(:,:,:,ii)];
    imshow(tile(:,:,:),[]);
    frame = getframe;
    writeVideo(v,frame);
end

close(1);
close(v);