function p=ChambolleProjector3D(in,lambda,Niter,alpha)

%======================================================
%
%  function p=ChambolleProjector3D(in,lambda,Nitermax)
%
%  This function compute the Chambolle's projector
%  used to compute the G-norm in the cartoon+texture
%  decomposition model of Aujol
%
%  Input parameter:
%  in: input image
%  lambda: Chambolle's parameter
%  Niter: maximum number of iteration
%
%  Output:
%  p: result of the projector
%
%  Auhtor: J.Gilles
%  Institution: SDSU - Department of Mathematics & Statistics
%  email: jgilles@mail.sdsu.edu
%  Date: July, 21th, 2016
%
%======================================================

tau=0.24;
c=tau/lambda;
n=0;
maxerror=0.001*norm(in(:),'fro');

[H,L,T]=size(in);

%Variable initialization
w=zeros(size(in));
phix=zeros(size(in));
phiy=zeros(size(in));
phit=zeros(size(in));
dxw=zeros(size(in));
dyw=zeros(size(in));
dtw=zeros(size(in));

err=maxerror+1;
while (n<Niter) && (err>maxerror),
    %update w
    w=lambda*w-in;
    
    %compute w gradients and its norm
    dyw(2:H-1,:,:)=0.5*(w(3:H,:,:)-w(1:H-2,:,:));
    dyw(1,:,:)=0.5*(w(2,:,:)-w(1,:,:));
    dyw(H,:,:)=0.5*(w(H,:,:)-w(H-1,:,:));
    
    dxw(:,2:L-1,:)=0.5*(w(:,3:L,:)-w(:,1:L-2,:));
    dxw(:,1,:)=0.5*(w(:,2,:)-w(:,1,:));
    dxw(:,L,:)=0.5*(w(:,L,:)-w(:,L-1,:));

    dtw(:,:,2:T-1)=0.5*(w(:,:,3:T)-w(:,:,1:T-2));
    dtw(:,:,1)=0.5*(w(:,:,2)-w(:,:,1));
    dtw(:,:,T)=(0.5*(w(:,:,T)-w(:,:,T-1)))/alpha;

    norm1=sqrt(dxw.^2+dyw.^2+dtw.^2);
    
    %update the projector
    npx=(phix+c*dxw)./(1+c*norm1);
    npy=(phiy+c*dyw)./(1+c*norm1);
    npt=(phit+c*dtw)./(1+c*norm1);
    err=max([norm(phix(:)-npx(:),'fro'),norm(phiy(:)-npy(:),'fro'),norm(phit(:)-npt(:),'fro')]);
    
    phix=npx;
    phiy=npy;
    phit=npt;
    
    %compute the divergence of phix, phiy and phit
    dyw(2:H-1,:,:)=0.5*(phiy(3:H,:,:)-phiy(1:H-2,:,:));
    dyw(1,:,:)=0.5*(phiy(2,:,:)-phiy(1,:,:));
    dyw(H,:,:)=0.5*(phiy(H,:,:)-phiy(H-1,:,:));
    
    dxw(:,2:L-1,:)=0.5*(phix(:,3:L,:)-phix(:,1:L-2,:));
    dxw(:,1,:)=0.5*(phix(:,2,:)-phix(:,1,:));
    dxw(:,H,:)=0.5*(phix(:,L,:)-phix(:,L-1,:));
    
    dtw(:,:,2:T-1)=0.5*(phit(:,:,3:T)-phit(:,:,1:T-2));
    dtw(:,:,1)=0.5*(phit(:,:,2)-phit(:,:,1));
    dtw(:,:,T)=(0.5*(phit(:,:,T)-phit(:,:,T-1)))/alpha;
    w=dxw+dyw+dtw;
    n=n+1;
end
p=lambda*w;