function [seq] = img2seq()
[FileNames,PathName]=uigetfile({'.png'},'Select multiple images', 'MultiSelect', 'on');
nfiles = length(FileNames); 


% Load image structure
if nfiles>1
    image = imread([PathName, FileNames{1}]);
    if length(size(image)) == 3
      test =rgb2gray(image);
    else
      test=image;
    end
    [row, col] = size(test);
    strRow = num2str(row);  strCol = num2str(col);
    prompt = {['Matrix Size: ',strRow, ' X ', strCol, ' X ', num2str(nfiles)], 'Crop Row', 'Crop Column', 'Skip'};
    title = 'Enter resize value:';
    dims = [1 35];
    definput = {'1', strRow, strCol, '1'};
    answer = inputdlg(prompt,title,dims,definput);
    
    if isempty(answer)
        resizeValue = 1;
        rowCrop = row;
        colCrop = col;
        skip=1;
    else
        resizeValue = str2double(answer{1});
        rowCrop = str2double(answer{2});
        colCrop = str2double(answer{3});
        skip = str2double(answer{4});
    end
    seq = zeros(rowCrop, colCrop, length(1:skip:nfiles));
    kk=0;
    for ii = 1:skip:nfiles
        kk=kk+1;
      image = imread([PathName, FileNames{ii}]);
      if length(size(image)) == 3
          tmp = imresize(rgb2gray(image), resizeValue);
          seq(:,:,kk) = tmp(round(row/2-rowCrop/2)+1 : round(row/2+rowCrop/2), round(col/2-colCrop/2) +1: round(col/2+colCrop/2));
      else
          seq(:,:,kk) = imresize(image, resizeValue);
      end
    end
    seq = (seq-min(seq(:)))/(max(seq(:))-min(seq(:)));
else
    disp('No files selected, returning empty array')
    seq=[];
end