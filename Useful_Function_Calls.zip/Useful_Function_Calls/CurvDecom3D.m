function [u,v]=CurvDecom3D(f,delta,lambda,Niter)

u=zeros(size(f));
v=zeros(size(f));

for n=1:Niter
    fprintf('n=%d \n',n);
   tmp=f-u;
   v=tmp-CurveletProj3D(tmp,2*delta);
   u=CurveletProj3D(f-v,2*lambda);
end