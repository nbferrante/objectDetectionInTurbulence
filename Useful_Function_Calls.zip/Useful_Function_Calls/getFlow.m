function [flow] = getFlow(J, method)
switch method
    case 'Demon'
    Demonflow=zeros(size(J,1),size(J,2),2,size(J,3)-1);
    demon_frames = size(J,3)-1;
    for t=1:demon_frames
        [Demonflow(:,:,:,t),~]=imregdemons(J(:,:,t+1),J(:,:,t), 'DisplayWaitbar', false);
        clc
        fprintf('Demon flow: %d of %d completed', t, demon_frames)
    end
    flow = Demonflow;

    case 'HS'
    HSflow = Sequence_HornSchunck_flow(J, 20, 0.5, 0.001 ,10, 10, 150);
    tmp = HSflow(:, :, 1, :);
    HSflow(:, :, 1, :) = HSflow(:, :, 2, :);
    HSflow(:, :, 2, :) = tmp;
    flow = HSflow;

    case 'TVL1'
    tvl1flow = Sequence_TVL1_flow(J, 0.25, 0.15, 0.3, 0.5, 0.01, 5, 100);
    tmp = tvl1flow(:, :, 1, :);
    tvl1flow(:, :, 1, :) = tvl1flow(:, :, 2, :);
    tvl1flow(:, :, 2, :) = tmp;
    flow = tvl1flow;
    otherwise
    tvl1flow = Sequence_TVL1_flow(J, 0.25, 0.15, 0.3, 0.5, 0.01, 5, 100);
    tmp = tvl1flow(:, :, 1, :);
    tvl1flow(:, :, 1, :) = tvl1flow(:, :, 2, :);
    tvl1flow(:, :, 2, :) = tmp;
    flow = tvl1flow;
end
end