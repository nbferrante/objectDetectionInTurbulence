function SaveSeq2Video(f,name)



v = VideoWriter(name);
open(v);
set(gca,'nextplot'); 
figure(1);
if size(size(f), 2) == 3
    f=uint8(255*(f-min(f(:)))/(max(f(:))-min(f(:))));
    tile=zeros(size(f,1),size(f,2),'uint8');
    for ii = 1:size(f,3)
        tile(:,:) = f(:,:,ii);
        imshow(tile(:,:),[]);
        frame = getframe;
        writeVideo(v,frame);
    end
elseif size(size(f), 2) == 4
    tile=zeros(size(f,1),size(f,2), size(f,3),'uint8');
    for ii = 1:size(f,4)
        tile(:,:,:) = f(:,:,:,ii);
        imshow(tile(:,:,:),[]);
        frame = getframe;
        writeVideo(v,frame);
    end
end

close(1);
close(v);